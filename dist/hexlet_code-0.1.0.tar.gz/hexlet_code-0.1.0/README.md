### Hexlet tests and linter status:
[![Actions Status](https://github.com/farakos/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/farakos/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/c67f46b7369db1a0e35d/maintainability)](https://codeclimate.com/github/farakos/python-project-49/maintainability)

[Installation and gameplay screencast](https://asciinema.org/a/CDbrCbgNbxQ02EI5aYp2ijP7Y)
